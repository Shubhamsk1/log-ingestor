import org.apache.kafka.clients.consumer.{ConsumerRecords, KafkaConsumer, OffsetResetStrategy}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.errors.WakeupException
import play.api.libs.json.{JsArray, JsSuccess, Json}
import scalikejdbc._

import java.time.Duration
import scala.jdk.CollectionConverters._
import scala.util.{Try, Using}

case class LogInput(
  level: String,
  message: String,
  resourceId: String,
  timestamp: String,
  traceId: String,
  spanId: String,
  commit: String,
  parentResourceId: Option[String]
)

object LogConsumer extends App {

  val bootstrapServers = sys.env.getOrElse("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
  val dbUrl = sys.env.getOrElse("DB_URL", "jdbc:postgresql://localhost:5432/logs_ingestor_db")
  val dbUser = sys.env.getOrElse("DB_USERNAME", "shubhamkudekar")
  val dbPass = sys.env.getOrElse("DB_PASSWORD", "")
  val topic = "logs-raw"
  val batchSize = 100

  // Setup DB connection pool
  ConnectionPool.singleton(dbUrl, dbUser, dbPass)

  // Setup Kafka consumer
  val props = new java.util.Properties()
  props.put("bootstrap.servers", bootstrapServers)
  props.put("group.id", "log-ingestor-consumer")
  props.put("key.deserializer", classOf[StringDeserializer].getName)
  props.put("value.deserializer", classOf[StringDeserializer].getName)
  props.put("auto.offset.reset", "earliest")
  props.put("enable.auto.commit", "false")
  props.put("max.poll.records", batchSize.toString)

  val consumer = new KafkaConsumer[String, String](props)
  consumer.subscribe(List(topic).asJava)

  // Shutdown hook
  val mainThread = Thread.currentThread()
  Runtime.getRuntime.addShutdownHook(new Thread() {
    override def run(): Unit = {
      consumer.wakeup()
      mainThread.join()
    }
  })

  println(s"Consumer started — bootstrap: $bootstrapServers, topic: $topic")

  try {
    while (true) {
      val records: ConsumerRecords[String, String] = consumer.poll(Duration.ofMillis(1000))

      if (!records.isEmpty) {
        val logs = records.asScala.flatMap { record =>
          parseLogs(record.value())
        }.toSeq

        if (logs.nonEmpty) {
          insertLogs(logs)
          consumer.commitSync()
          println(s"Ingested ${logs.length} logs")
        }
      }
    }
  } catch {
    case _: WakeupException => // expected on shutdown
    case e: Exception       => println(s"Consumer error: ${e.getMessage}")
  } finally {
    consumer.close()
    println("Consumer shut down")
  }

  def parseLogs(json: String): Seq[LogInput] = {
    Try {
      Json.parse(json) match {
        case arr: JsArray =>
          arr.value.flatMap { entry =>
            val level   = (entry \ "level").asOpt[String]
            val message = (entry \ "message").asOpt[String]
            val rid     = (entry \ "resourceId").asOpt[String].orElse((entry \ "resource_id").asOpt[String])
            val ts      = (entry \ "timestamp").asOpt[String]
            val tid     = (entry \ "traceId").asOpt[String].orElse((entry \ "trace_id").asOpt[String])
            val sid     = (entry \ "spanId").asOpt[String].orElse((entry \ "span_id").asOpt[String])
            val cmt     = (entry \ "commit").asOpt[String]
            val parent  = (entry \ "metadata" \ "parentResourceId").asOpt[String]
              .orElse((entry \ "metadata" \ "parent_resource_id").asOpt[String])

            (level, message, rid, ts, tid, sid, cmt) match {
              case (Some(l), Some(m), Some(r), Some(t), Some(ti), Some(s), Some(c)) =>
                Some(LogInput(l, m, r, t, ti, s, c, parent))
              case _ => None
            }
          }.toSeq
        case _ => Seq.empty
      }
    }.getOrElse {
      println(s"Failed to parse: $json")
      Seq.empty
    }
  }

  def insertLogs(logs: Seq[LogInput]): Unit = {
    DB.localTx { implicit session =>
      logs.foreach { log =>
        sql"""
          INSERT INTO logs (level, message, resource_id, timestamp, trace_id, span_id, commit, parent_resource_id)
          VALUES (
            ${log.level},
            ${log.message},
            ${log.resourceId},
            ${log.timestamp}::timestamptz,
            ${log.traceId},
            ${log.spanId},
            ${log.commit},
            ${log.parentResourceId.getOrElse("")}
          )
        """.update().apply()
      }
    }
  }
}
